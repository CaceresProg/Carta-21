onload = () => {
  document.body.classList.remove("container");
};

window.addEventListener("click", () => {
  const audio = document.getElementById("campanitas");
  audio.play();
}, { once: true });

